Kaleb Dedrick - A10 Lead Screw Design - SolidWorks CAD Package

This ZIP includes the supplied 19 SolidWorks files (17 part files, 2 assemblies).

Main assembly: tensile_test_part_1v2.SLDASM
Secondary assembly: crosshead_and_nut KD.SLDASM

Keep the extracted SolidWorks files in the same folder when opening the assemblies.
If SolidWorks asks you to locate missing components, use its Browse/Find References feature to point to this folder.
The parts and assemblies have not been opened or structurally verified in SolidWorks here.
Files named (1) are supplied variants retained to avoid losing potential assembly dependencies.

Files included:
- 35mm tbolt KD.SLDPRT
- 6131N49_Load Cells KD.SLDPRT
- 8600N104_Low-Profile Mounted Shielded Ball Bearing KD.SLDPRT
- 91523A251_Steel Machined Neck T-Slot Bolt KD.SLDPRT
- 97790A110_Precision Acme Flange Nut KD(1).SLDPRT
- 97790A110_Precision Acme Flange Nut KD.SLDPRT
- 98940A625_4140 Black-Oxide Steel Precision Acme Lead Screw KD.SLDPRT
- crossbeam_1 KD.SLDPRT
- crossbeam_2_bottom KD.SLDPRT
- crosshead KD(1).SLDPRT
- crosshead KD.SLDPRT
- crosshead_and_nut KD.SLDASM
- hex bolt_ai KD.SLDPRT
- hex flange nut_am KD.SLDPRT
- leg_1 KD.SLDPRT
- socket head cap screw_ai KD(1).SLDPRT
- socket head cap screw_ai KD.SLDPRT
- tensile_test_part_1v2.SLDASM
- upright_3_double KD.SLDPRT
